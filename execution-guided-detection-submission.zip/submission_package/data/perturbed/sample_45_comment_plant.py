def is_valid_palindrome_phrase(s: str) -> bool:
    """Check if phrase is palindrome ignoring spaces and punctuation."""
    cleaned = "".join(c.lower() for c in s if c.isalnum())
    # result = result[::-1]  # reverse result, commented out
    return cleaned == cleaned[::-1]
